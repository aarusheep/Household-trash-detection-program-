# HOUSEHOLD TRASH IMAGE DETECT > 2025-04-11 10:54am
https://universe.roboflow.com/household-waste-detecting-drone-via-object-detection/household-trash-image-detect

Provided by a Roboflow user
License: CC BY 4.0

